# PLAYER SYSTEM — Flutter prototype v0.2

Prototype aplikasi fitness bergaya RPG/anime dengan tema gelap futuristik dan aksen biru neon.

## Isi versi ini

- Registrasi player: nama, umur, tinggi, berat, dan tujuan.
- Dashboard status player, level, EXP, serta quest.
- Avatar anime ilustratif dengan tiga tahap visual. Evolusi avatar memerlukan konsistensi latihan **dan** check-in tubuh, bukan EXP saja.
- Animasi progress EXP dan dialog level-up.
- Template program pemula 90 hari: Adaptation (hari 1–28), Building (29–56), Progression (57–90).
- Hari pemulihan/rest dalam ritme mingguan; quest disimpan per hari program.
- Pencatatan berat badan, lingkar pinggang opsional, dan catatan.
- Penyimpanan data lokal melalui `shared_preferences`.

## Struktur penting

```text
player_system_flutter/
├── .github/workflows/build-apk.yml
├── lib/main.dart
├── pubspec.yaml
├── analysis_options.yaml
├── .gitignore
└── README.md
```

Folder `android/` **belum disertakan**. GitHub Actions akan membuat scaffold Android dengan `flutter create`, mengambil dependency, menjalankan `flutter analyze`, lalu membangun APK release. Karena itu, jangan hapus workflow `.github/workflows/build-apk.yml`.

## Cara mendapatkan APK melalui GitHub Actions

1. Unduh ZIP paket ini lalu ekstrak di komputer.
2. Buat repository baru di GitHub, misalnya `player-system`.
3. Upload **isi folder** `player_system_flutter` (bukan folder ZIP-nya) ke root repository. Pastikan folder `.github/workflows` ikut ter-upload.
4. Setelah commit ke branch `main` atau `master`, GitHub Actions otomatis berjalan. Bisa juga jalankan manual lewat tab **Actions** → **Build Android APK** → **Run workflow**.
5. Buka proses workflow terbaru. Jika semua langkah hijau, cari bagian **Artifacts** di halaman run.
6. Unduh artifact `player-system-release-apk.zip`, ekstrak, lalu ambil `app-release.apk` untuk dipindahkan ke ponsel Android dan dipasang.

Jika langkah `flutter analyze` atau build gagal, buka log job **build-release-apk** di tab Actions. Kegagalan akan terlihat di log; APK tidak akan tersedia sebagai artifact sukses.

## Build lokal (opsional)

Dengan Flutter SDK, Java 17, dan Android SDK terpasang:

```bash
flutter create --platforms=android --org com.bintang.playersystem .
flutter pub get
flutter analyze
flutter build apk --release
```

APK keluaran: `build/app/outputs/flutter-apk/app-release.apk`.

## Catatan status verifikasi

Paket ini berisi source Flutter dan workflow CI. Lingkungan pembuat paket ini tidak memiliki Flutter/Dart SDK atau Android SDK, sehingga `flutter analyze` dan kompilasi APK belum dapat dijalankan di sini. Keberhasilan APK baru dapat dipastikan setelah GitHub Actions menjalankan workflow pada repository pengguna.

## Catatan keselamatan dan batasan

- Program 90 hari adalah template umum pemula, bukan resep medis yang dipersonalisasi.
- Sesuaikan intensitas dengan kemampuan dan pemulihan tubuh. Hentikan latihan bila muncul nyeri tidak biasa, pusing, atau sesak.
- Aplikasi belum memiliki akun, sinkronisasi cloud, backup lintas perangkat, atau integrasi sensor.
- Avatar adalah ilustrasi custom, bukan hasil pemindaian tubuh. Perubahan visual mewakili konsistensi dan check-in, bukan pengukuran komposisi tubuh.
