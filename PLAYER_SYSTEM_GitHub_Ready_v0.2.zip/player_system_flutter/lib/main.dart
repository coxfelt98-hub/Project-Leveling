import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const PlayerSystemApp());

const bg = Color(0xFF070B14);
const panel = Color(0xFF101A2B);
const blue = Color(0xFF35B9FF);
const muted = Color(0xFF8DA4BC);

class PlayerSystemApp extends StatelessWidget {
  const PlayerSystemApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'PLAYER SYSTEM',
    theme: ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: bg,
      colorScheme: ColorScheme.fromSeed(seedColor: blue, brightness: Brightness.dark),
      useMaterial3: true,
      inputDecorationTheme: InputDecorationTheme(
        filled: true, fillColor: panel,
        labelStyle: const TextStyle(color: muted),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
      ),
    ),
    home: const RootPage(),
  );
}

class BodyLog {
  final String date;
  final double weight;
  final double? waist;
  final String note;
  BodyLog(this.date, this.weight, this.waist, this.note);
  Map<String, dynamic> toJson() => {'date': date, 'weight': weight, 'waist': waist, 'note': note};
  factory BodyLog.fromJson(Map<String, dynamic> j) => BodyLog(
    j['date'] as String, (j['weight'] as num).toDouble(),
    (j['waist'] as num?)?.toDouble(), (j['note'] ?? '') as String,
  );
}

class RootPage extends StatefulWidget {
  const RootPage({super.key});
  @override
  State<RootPage> createState() => _RootPageState();
}

class _RootPageState extends State<RootPage> {
  bool loading = true;
  String name = '', goal = 'Bentuk badan';
  int age = 24, exp = 0, programDay = 0;
  double height = 170, weight = 75;
  DateTime? programStart;
  Map<int, Set<int>> doneByDay = {};
  List<BodyLog> logs = [];

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    final rawDone = p.getString('doneByDay');
    final rawLogs = p.getString('bodyLogs');
    setState(() {
      name = p.getString('name') ?? '';
      age = p.getInt('age') ?? 24;
      height = p.getDouble('height') ?? 170;
      weight = p.getDouble('weight') ?? 75;
      goal = p.getString('goal') ?? 'Bentuk badan';
      exp = p.getInt('exp') ?? 0;
      programDay = p.getInt('programDay') ?? 0;
      final start = p.getString('programStart');
      programStart = start == null ? null : DateTime.tryParse(start);
      if (rawDone != null) {
        final decoded = jsonDecode(rawDone) as Map<String, dynamic>;
        doneByDay = decoded.map((k, v) => MapEntry(int.parse(k), (v as List).cast<int>().toSet()));
      } else {
        // Migrate the original v0.1 one-day quest checklist.
        final legacy = p.getStringList('completed');
        if (legacy != null && legacy.isNotEmpty) doneByDay[0] = legacy.map(int.parse).toSet();
      }
      if (rawLogs != null) logs = (jsonDecode(rawLogs) as List).map((e) => BodyLog.fromJson(e as Map<String, dynamic>)).toList();
      loading = false;
    });
  }

  Future<void> _save() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('name', name);
    await p.setInt('age', age);
    await p.setDouble('height', height);
    await p.setDouble('weight', weight);
    await p.setString('goal', goal);
    await p.setInt('exp', exp);
    await p.setInt('programDay', programDay);
    if (programStart != null) await p.setString('programStart', programStart!.toIso8601String());
    await p.setString('doneByDay', jsonEncode(doneByDay.map((k, v) => MapEntry('$k', v.toList()))));
    await p.setString('bodyLogs', jsonEncode(logs.map((e) => e.toJson()).toList()));
  }

  int get level => 1 + exp ~/ 500;
  int get levelExp => exp % 500;
  int get trainingSessions => doneByDay.values.fold<int>(0, (n, s) => n + (s.isEmpty ? 0 : 1));
  int get avatarStage {
    // Avatar evolves only after repeated, dated body check-ins AND training consistency.
    if (trainingSessions >= 20 && logs.length >= 5) return 2;
    if (trainingSessions >= 6 && logs.length >= 2) return 1;
    return 0;
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Scaffold(body: Center(child: CircularProgressIndicator(color: blue)));
    if (name.isEmpty) return RegistrationPage(onSave: (n, a, h, w, g) async {
      setState(() { name = n; age = a; height = h; weight = w; goal = g; programStart = DateTime.now(); programDay = 0; });
      await _save();
    });
    return DashboardPage(
      name: name, age: age, height: height, weight: weight, goal: goal,
      exp: exp, level: level, levelExp: levelExp, programDay: programDay,
      completed: doneByDay[programDay] ?? <int>{}, logs: logs,
      trainingSessions: trainingSessions, avatarStage: avatarStage,
      onQuestDone: (id, points) async {
        final set = doneByDay.putIfAbsent(programDay, () => <int>{});
        if (set.add(id)) {
          final before = level;
          setState(() => exp += points);
          await _save();
          if (level > before && mounted) _showLevelUp();
        }
      },
      onNextDay: () async { setState(() { if (programDay < 89) programDay++; }); await _save(); },
      onLog: (w, waist, note) async {
        final today = dateKey(DateTime.now());
        setState(() {
          logs.removeWhere((e) => e.date == today);
          logs.add(BodyLog(today, w, waist, note));
          logs.sort((a, b) => a.date.compareTo(b.date));
          weight = w;
        });
        await _save();
      },
      onReset: () async { final p = await SharedPreferences.getInstance(); await p.clear(); setState(() { name = ''; exp = 0; programDay = 0; doneByDay.clear(); logs.clear(); }); },
    );
  }

  void _showLevelUp() => showDialog<void>(context: context, builder: (c) => AlertDialog(
    backgroundColor: panel,
    title: const Text('LEVEL UP!', textAlign: TextAlign.center, style: TextStyle(color: blue, fontWeight: FontWeight.w900, letterSpacing: 2)),
    content: const Column(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.bolt, color: blue, size: 72), Text('Your effort is getting stronger.', textAlign: TextAlign.center)]),
    actions: [FilledButton(onPressed: () => Navigator.pop(c), child: const Text('CONTINUE'))],
  ));
}

String dateKey(DateTime d) => '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

class RegistrationPage extends StatefulWidget {
  final Future<void> Function(String, int, double, double, String) onSave;
  const RegistrationPage({super.key, required this.onSave});
  @override
  State<RegistrationPage> createState() => _RegistrationPageState();
}
class _RegistrationPageState extends State<RegistrationPage> {
  final form = GlobalKey<FormState>();
  final name = TextEditingController(), age = TextEditingController(text: '24'), height = TextEditingController(text: '170'), weight = TextEditingController(text: '75');
  String goal = 'Turunkan berat badan';
  @override
  void dispose() { name.dispose(); age.dispose(); height.dispose(); weight.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => Scaffold(body: SafeArea(child: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(24), child: Form(key: form, child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
    const Icon(Icons.bolt, color: blue, size: 54), const SizedBox(height: 12),
    const Text('PLAYER SYSTEM', textAlign: TextAlign.center, style: TextStyle(fontSize: 27, fontWeight: FontWeight.w900, letterSpacing: 3)),
    const SizedBox(height: 8), const Text('INITIALIZE YOUR CHARACTER', textAlign: TextAlign.center, style: TextStyle(color: blue, letterSpacing: 2, fontSize: 11)),
    const SizedBox(height: 32), const Text('IDENTITAS PLAYER', style: TextStyle(color: blue, fontWeight: FontWeight.bold)), const SizedBox(height: 14),
    TextFormField(controller: name, decoration: const InputDecoration(labelText: 'Nama player'), validator: (v) => v == null || v.trim().isEmpty ? 'Masukkan nama player' : null),
    const SizedBox(height: 12), Row(children: [Expanded(child: TextFormField(controller: age, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Umur'), validator: (v) => numberError(v, 13, 100))), const SizedBox(width: 12), Expanded(child: TextFormField(controller: height, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Tinggi (cm)'), validator: (v) => numberError(v, 100, 230)))]),
    const SizedBox(height: 12), TextFormField(controller: weight, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'Berat badan (kg)'), validator: (v) => numberError(v, 30, 300)),
    const SizedBox(height: 26), const Text('PILIH MISI UTAMA', style: TextStyle(color: blue, fontWeight: FontWeight.bold)), const SizedBox(height: 12),
    goalTile('Turunkan berat badan', Icons.local_fire_department), const SizedBox(height: 10), goalTile('Bentuk badan', Icons.fitness_center), const SizedBox(height: 26),
    FilledButton(style: FilledButton.styleFrom(backgroundColor: blue, foregroundColor: bg, padding: const EdgeInsets.symmetric(vertical: 17)), onPressed: () async { if (!form.currentState!.validate()) return; await widget.onSave(name.text.trim(), int.parse(age.text), double.parse(height.text), double.parse(weight.text.replaceAll(',', '.')), goal); }, child: const Text('AWAKEN PLAYER', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.5))),
    const SizedBox(height: 14), const Text('Program awal memakai asumsi pemula. Sesuaikan gerakan dengan kemampuan; hentikan jika terasa nyeri atau pusing.', textAlign: TextAlign.center, style: TextStyle(color: muted, fontSize: 11)),
  ]))))));
  Widget goalTile(String value, IconData icon) { final selected = goal == value; return InkWell(onTap: () => setState(() => goal = value), borderRadius: BorderRadius.circular(14), child: Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: selected ? const Color(0xFF102B42) : panel, borderRadius: BorderRadius.circular(14), border: Border.all(color: selected ? blue : Colors.white10)), child: Row(children: [Icon(icon, color: blue), const SizedBox(width: 12), Expanded(child: Text(value, style: const TextStyle(fontWeight: FontWeight.bold))), Icon(selected ? Icons.radio_button_checked : Icons.radio_button_off, color: selected ? blue : muted)]))); }
}
String? numberError(String? v, num min, num max) { final n = num.tryParse((v ?? '').replaceAll(',', '.')); if (n == null || n < min || n > max) return 'Isi angka $min–$max'; return null; }

class Exercise { final String name, dose, tip; final int exp; final IconData icon; const Exercise(this.name, this.dose, this.tip, this.exp, this.icon); }
class DayPlan { final String title, type, note; final List<Exercise> exercises; const DayPlan(this.title, this.type, this.note, this.exercises); }

DayPlan buildPlan(int day, String goal) {
  final weekDay = day % 7; // 0 strength, 1 cardio, 2 recovery, 3 strength, 4 cardio, 5 strength/cardio, 6 rest
  final phase = day < 28 ? 0 : day < 56 ? 1 : 2;
  final sets = phase == 0 ? 2 : 3;
  final rep = phase == 0 ? '8–10' : phase == 1 ? '10–12' : '10–12';
  final walk = phase == 0 ? '15–20 menit' : phase == 1 ? '20–25 menit' : '25–30 menit';
  if (weekDay == 6) return const DayPlan('Rest & Recovery', 'HARI ISTIRAHAT', 'Hari ini tidak ada latihan yang harus dilakukan. Tidur cukup, makan teratur, dan beri tubuh waktu pulih.', [
    Exercise('Recovery day', 'Istirahat', 'Tandai hari pemulihan selesai. Jalan santai hanya jika memang terasa nyaman.', 0, Icons.bedtime_outlined),
  ]);
  if (weekDay == 2) return const DayPlan('Active Recovery', 'PEMULIHAN AKTIF', 'Gerakan ringan saja. Tidak perlu mengejar intensitas atau berkeringat.', [
    Exercise('Mobility ringan', '5 menit', 'Gerakkan sendi perlahan, tanpa memaksa rentang gerak.', 10, Icons.self_improvement),
  ]);
  if (weekDay == 1 || weekDay == 4 || (weekDay == 5 && goal == 'Turunkan berat badan')) return DayPlan('Cardio & Mobility', 'KARDIO RINGAN', 'Pace sedang: masih bisa berbicara dalam kalimat pendek.', [
    Exercise('Jalan cepat', walk, 'Mulai pelan 3–5 menit, lalu tingkatkan ke pace nyaman.', 25, Icons.directions_walk),
    const Exercise('Peregangan ringan', '5 menit', 'Tidak perlu memantul atau menahan sakit.', 15, Icons.self_improvement),
  ]);
  final strength = <Exercise>[
    Exercise('Squat ke kursi', '$sets × $rep', 'Gunakan kursi sebagai target; lutut mengikuti arah jari kaki.', 25, Icons.fitness_center),
    Exercise('Wall / incline push-up', '$sets × $rep', 'Pilih posisi yang membuat repetisi tetap terkontrol.', 25, Icons.accessibility_new),
    Exercise('Glute bridge', '$sets × $rep', 'Angkat pinggul tanpa melengkungkan pinggang berlebihan.', 20, Icons.sports_gymnastics),
    Exercise('Bird-dog', '$sets × 8 per sisi', 'Jaga badan stabil dan bergerak perlahan.', 20, Icons.accessibility),
  ];
  if (goal == 'Turunkan berat badan') strength.add(Exercise('Jalan santai penutup', phase == 0 ? '5 menit' : '8–10 menit', 'Pendinginan ringan.', 10, Icons.directions_walk));
  return DayPlan(weekDay == 5 ? 'Full Body Strength' : 'Full Body Strength', 'KEKUATAN', 'Istirahat 60–90 detik antar set. Sisakan tenaga; jangan latihan sampai gagal.', strength);
}

class DashboardPage extends StatefulWidget {
  final String name, goal; final int age, exp, level, levelExp, programDay, trainingSessions, avatarStage;
  final double height, weight; final Set<int> completed; final List<BodyLog> logs;
  final Future<void> Function(int, int) onQuestDone; final Future<void> Function() onNextDay;
  final Future<void> Function(double, double?, String) onLog;
  final Future<void> Function() onReset;
  const DashboardPage({super.key, required this.name, required this.age, required this.height, required this.weight, required this.goal, required this.exp, required this.level, required this.levelExp, required this.programDay, required this.completed, required this.logs, required this.trainingSessions, required this.avatarStage, required this.onQuestDone, required this.onNextDay, required this.onLog, required this.onReset});
  @override
  State<DashboardPage> createState() => _DashboardPageState();
}
class _DashboardPageState extends State<DashboardPage> {
  int tab = 0;
  DayPlan get plan => buildPlan(widget.programDay, widget.goal);
  bool get dayComplete => plan.exercises.asMap().keys.every(widget.completed.contains);
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('PLAYER SYSTEM', style: TextStyle(letterSpacing: 2, fontWeight: FontWeight.w900)), actions: [IconButton(tooltip: 'Reset data', onPressed: _confirmReset, icon: const Icon(Icons.settings_outlined))]),
    body: IndexedStack(index: tab, children: [_home(), _training(), _progress(), _profile()]),
    bottomNavigationBar: NavigationBar(backgroundColor: panel, indicatorColor: const Color(0xFF163D58), selectedIndex: tab, onDestinationSelected: (v) => setState(() => tab = v), destinations: const [NavigationDestination(icon: Icon(Icons.dashboard_outlined), label: 'Status'), NavigationDestination(icon: Icon(Icons.assignment_outlined), label: 'Training'), NavigationDestination(icon: Icon(Icons.monitor_heart_outlined), label: 'Progress'), NavigationDestination(icon: Icon(Icons.person_outline), label: 'Player')]),
  );

  Widget _home() => ListView(padding: const EdgeInsets.all(18), children: [
    Container(padding: const EdgeInsets.all(18), decoration: box(), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('PLAYER DETECTED', style: TextStyle(color: blue, fontSize: 11, letterSpacing: 2)), const SizedBox(height: 8),
      Text(widget.name.toUpperCase(), style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w900)), Text('LEVEL ${widget.level}', style: const TextStyle(color: blue, fontWeight: FontWeight.bold, letterSpacing: 2)),
      const SizedBox(height: 12), Row(children: [
        AnimatedSwitcher(duration: const Duration(milliseconds: 500), child: Container(key: ValueKey(widget.avatarStage), width: 118, height: 142, decoration: BoxDecoration(borderRadius: BorderRadius.circular(16), gradient: const LinearGradient(colors: [Color(0xFF123B59), Color(0xFF08111E)])), child: CustomPaint(painter: AnimeAvatarPainter(stage: widget.avatarStage))),
        const SizedBox(width: 16), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('ANIME PLAYER AVATAR', style: TextStyle(color: muted, fontSize: 10, letterSpacing: 1.2)), const SizedBox(height: 8), Text(avatarName(widget.avatarStage), style: const TextStyle(fontSize: 18, color: blue, fontWeight: FontWeight.w900)), const SizedBox(height: 6), Text(avatarDescription(widget.avatarStage), style: const TextStyle(color: muted, fontSize: 12, height: 1.4)), const SizedBox(height: 8), Text('${widget.trainingSessions} training days • ${widget.logs.length} body logs', style: const TextStyle(fontSize: 10, color: muted))]))
      ]),
      const SizedBox(height: 18), Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [const Text('EXPERIENCE', style: TextStyle(color: muted, fontSize: 11, letterSpacing: 1.5)), Text('${widget.levelExp} / 500 EXP', style: const TextStyle(color: blue, fontWeight: FontWeight.bold))]), const SizedBox(height: 8),
      ClipRRect(borderRadius: BorderRadius.circular(20), child: TweenAnimationBuilder<double>(tween: Tween(begin: 0, end: widget.levelExp / 500), duration: const Duration(milliseconds: 700), builder: (c, v, _) => LinearProgressIndicator(value: v, minHeight: 9, backgroundColor: Colors.white10, color: blue))), Text('${widget.exp} TOTAL EXP', style: const TextStyle(color: muted, fontSize: 11)),
    ]))),
    const SizedBox(height: 14), Row(children: [Expanded(child: miniStat('HEIGHT', '${widget.height.toStringAsFixed(0)} cm')), const SizedBox(width: 8), Expanded(child: miniStat('WEIGHT', '${widget.weight.toStringAsFixed(1)} kg')), const SizedBox(width: 8), Expanded(child: miniStat('AGE', '${widget.age} yr'))]),
    const SizedBox(height: 18), section('CURRENT MISSION'), Container(padding: const EdgeInsets.all(16), decoration: box(), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('DAY ${widget.programDay + 1} / 90', style: const TextStyle(color: blue, fontWeight: FontWeight.w900, letterSpacing: 1.5)), const SizedBox(height: 6), Text(plan.title, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold)), Text(plan.type, style: const TextStyle(color: muted, fontSize: 10, letterSpacing: 1.3)), const SizedBox(height: 8), Text(plan.note, style: const TextStyle(color: muted, height: 1.4)), const SizedBox(height: 10), Text('${widget.completed.length} / ${plan.exercises.length} tasks complete', style: const TextStyle(color: blue, fontSize: 12)), const SizedBox(height: 8), FilledButton(onPressed: () => setState(() => tab = 1), child: const Text('OPEN TRAINING'))])),
    const SizedBox(height: 14), const Text('AVATAR EVOLUTION', style: TextStyle(color: blue, fontWeight: FontWeight.w900, letterSpacing: 1.4)), const SizedBox(height: 6), const Text('Level EXP membuka level pemain. Evolusi avatar membutuhkan konsistensi latihan dan catatan progres tubuh.', style: TextStyle(color: muted, fontSize: 12, height: 1.5)),
  ]);

  Widget _training() => ListView(padding: const EdgeInsets.all(18), children: [
    const Text('90-DAY TRAINING', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, letterSpacing: 1.2)), const SizedBox(height: 5), Text('OBJECTIVE: ${widget.goal.toUpperCase()}', style: const TextStyle(color: blue, fontSize: 11, letterSpacing: 1.2)), const SizedBox(height: 14),
    Container(padding: const EdgeInsets.all(15), decoration: box(), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('DAY ${widget.programDay + 1} / 90', style: const TextStyle(color: blue, fontWeight: FontWeight.w900)), const SizedBox(height: 8), LinearProgressIndicator(value: (widget.programDay + 1) / 90, color: blue, backgroundColor: Colors.white10), const SizedBox(height: 8), Text(phaseName(widget.programDay), style: const TextStyle(fontWeight: FontWeight.bold)), const Text('Minggu ${widget.programDay ~/ 7 + 1} • Volume latihan bertahap', style: TextStyle(color: muted, fontSize: 11))])),
    const SizedBox(height: 14), Text(plan.title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)), Text(plan.note, style: const TextStyle(color: muted, height: 1.5)), const SizedBox(height: 14),
    ...plan.exercises.asMap().entries.map((e) => exerciseTile(e.key, e.value)),
    if ((widget.programDay + 1) % 7 == 0) weeklyReviewCard(),
    const SizedBox(height: 10), if (dayComplete && widget.programDay < 89) FilledButton.icon(onPressed: () async { await widget.onNextDay(); if (mounted) setState(() {}); }, icon: const Icon(Icons.arrow_forward), label: const Text('COMPLETE DAY & NEXT')), if (dayComplete && widget.programDay == 89) const Text('PROGRAM 90 HARI SELESAI! Review progres dan tentukan target berikutnya.', style: TextStyle(color: blue, fontWeight: FontWeight.bold)),
    if (!dayComplete) const Text('Selesaikan semua tugas hari ini untuk membuka hari berikutnya. Pada hari pemulihan, aktivitas opsional juga dapat ditandai selesai.', style: TextStyle(color: muted, fontSize: 11, height: 1.4)),
    const SizedBox(height: 14), const Text('Catatan: program ini template pemula. Kurangi repetisi atau durasi bila perlu. Sisakan 1–2 repetisi sebelum kelelahan; hentikan latihan jika nyeri, pusing, atau sesak tidak biasa.', style: TextStyle(color: muted, fontSize: 11, height: 1.5)),
  ]);

  Widget weeklyReviewCard() => Container(
    margin: const EdgeInsets.only(top: 14), padding: const EdgeInsets.all(15),
    decoration: BoxDecoration(color: const Color(0xFF102B42), borderRadius: BorderRadius.circular(15), border: Border.all(color: blue.withOpacity(.45))),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('WEEKLY EVALUATION', style: TextStyle(color: blue, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
      const SizedBox(height: 6),
      const Text('Sebelum lanjut ke minggu berikutnya, evaluasi teknik gerakan, energi, kualitas tidur, dan pemulihan. Jika masih terlalu berat atau ada nyeri, ulangi level yang lebih ringan atau ambil waktu pulih.', style: TextStyle(color: muted, fontSize: 12, height: 1.45)),
      const SizedBox(height: 10),
      OutlinedButton.icon(onPressed: _showWeeklyReview, icon: const Icon(Icons.fact_check_outlined), label: const Text('OPEN WEEKLY REVIEW')),
    ]),
  );

  Future<void> _showWeeklyReview() async {
    await showDialog<void>(context: context, builder: (c) => AlertDialog(
      backgroundColor: panel,
      title: Text('WEEK ${((widget.programDay + 1) / 7).ceil()} REVIEW'),
      content: const SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('1. Apakah gerakan terasa terkontrol dan teknik tetap rapi?'), SizedBox(height: 10),
        Text('2. Apakah energi dan tidur cukup untuk pulih?'), SizedBox(height: 10),
        Text('3. Apakah ada nyeri tajam, pusing, atau sesak yang tidak biasa? Jika ya, jangan menaikkan intensitas; hentikan gerakan pemicu dan cari saran tenaga kesehatan bila perlu.'), SizedBox(height: 10),
        Text('4. Catat berat/lingkar pinggang di tab Progress jika ingin membandingkan tren mingguan.'),
      ])),
      actions: [FilledButton(onPressed: () => Navigator.pop(c), child: const Text('REVIEWED'))],
    ));
  }

  Widget exerciseTile(int id, Exercise e) { final done = widget.completed.contains(id); return Container(margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(15), border: Border.all(color: done ? blue.withOpacity(.55) : Colors.white10)), child: Row(children: [Icon(e.icon, color: blue, size: 27), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(e.name, style: const TextStyle(fontWeight: FontWeight.bold)), const SizedBox(height: 3), Text(e.dose, style: const TextStyle(color: blue, fontSize: 12)), Text(e.tip, style: const TextStyle(color: muted, fontSize: 11, height: 1.35)), Text('+${e.exp} EXP', style: const TextStyle(color: blue, fontSize: 10, fontWeight: FontWeight.bold))])), done ? const Icon(Icons.check_circle, color: blue) : IconButton(onPressed: () async { await widget.onQuestDone(id, e.exp); if (mounted) setState(() {}); }, icon: const Icon(Icons.add_circle_outline, color: blue, size: 28))])); }

  Widget _progress() => ListView(padding: const EdgeInsets.all(18), children: [
    const Text('BODY PROGRESS', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, letterSpacing: 1.2)), const SizedBox(height: 6), const Text('Catat pengukuran secara berkala, idealnya pada kondisi dan waktu yang mirip.', style: TextStyle(color: muted, height: 1.4)), const SizedBox(height: 16),
    FilledButton.icon(onPressed: _addLog, icon: const Icon(Icons.add), label: const Text('ADD BODY CHECK-IN')), const SizedBox(height: 16),
    if (widget.logs.isEmpty) Container(padding: const EdgeInsets.all(18), decoration: box(), child: const Text('Belum ada catatan. Tambahkan pengukuran pertama untuk mulai memantau progres.', style: TextStyle(color: muted))) else ...[
      Row(children: [Expanded(child: miniStat('LATEST WEIGHT', '${widget.logs.last.weight.toStringAsFixed(1)} kg')), const SizedBox(width: 8), Expanded(child: miniStat('CHECK-INS', '${widget.logs.length}'))]), const SizedBox(height: 12),
      ...widget.logs.reversed.map((l) => Container(margin: const EdgeInsets.only(bottom: 9), padding: const EdgeInsets.all(14), decoration: box(), child: Row(children: [const Icon(Icons.monitor_weight_outlined, color: blue), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(l.date, style: const TextStyle(color: muted, fontSize: 11)), Text('${l.weight.toStringAsFixed(1)} kg${l.waist == null ? '' : ' • pinggang ${l.waist!.toStringAsFixed(1)} cm'}', style: const TextStyle(fontWeight: FontWeight.bold)), if (l.note.isNotEmpty) Text(l.note, style: const TextStyle(color: muted, fontSize: 11))]))])))
    ],
    const SizedBox(height: 12), Container(padding: const EdgeInsets.all(14), decoration: box(), child: const Text('Berat badan dapat berfluktuasi karena cairan, makanan, dan faktor lain. Jangan mengejar penurunan cepat. Gunakan tren beberapa minggu, ukuran pinggang, energi, dan kekuatan sebagai konteks.', style: TextStyle(color: muted, fontSize: 11, height: 1.5))),
  ]);

  Future<void> _addLog() async { final w = TextEditingController(text: widget.weight.toStringAsFixed(1)); final waist = TextEditingController(); final note = TextEditingController(); final key = GlobalKey<FormState>(); final result = await showDialog<bool>(context: context, builder: (c) => AlertDialog(backgroundColor: panel, title: const Text('BODY CHECK-IN'), content: Form(key: key, child: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [TextFormField(controller: w, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'Berat (kg)'), validator: (v) => numberError(v, 30, 300)), const SizedBox(height: 10), TextFormField(controller: waist, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'Lingkar pinggang (cm) • opsional'), validator: (v) => v == null || v.isEmpty ? null : numberError(v, 30, 250)), const SizedBox(height: 10), TextField(controller: note, decoration: const InputDecoration(labelText: 'Catatan • opsional'))])), actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('CANCEL')), FilledButton(onPressed: () { if (key.currentState!.validate()) Navigator.pop(c, true); }, child: const Text('SAVE'))])); if (result == true) { await widget.onLog(double.parse(w.text.replaceAll(',', '.')), waist.text.isEmpty ? null : double.parse(waist.text.replaceAll(',', '.')), note.text.trim()); if (mounted) setState(() {}); } }

  Widget _profile() => ListView(padding: const EdgeInsets.all(18), children: [const Text('PLAYER PROFILE', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)), const SizedBox(height: 16), miniStat('PLAYER NAME', widget.name), miniStat('MAIN OBJECTIVE', widget.goal), miniStat('AGE', '${widget.age} tahun'), miniStat('HEIGHT', '${widget.height.toStringAsFixed(0)} cm'), miniStat('LATEST WEIGHT', '${widget.weight.toStringAsFixed(1)} kg'), miniStat('TOTAL EXPERIENCE', '${widget.exp} EXP'), miniStat('TRAINING DAYS', '${widget.trainingSessions}'), const SizedBox(height: 16), OutlinedButton.icon(onPressed: _confirmReset, icon: const Icon(Icons.restart_alt), label: const Text('RESET PLAYER DATA')), const SizedBox(height: 10), const Text('PLAYER SYSTEM • Prototype v0.2 • Data tersimpan lokal di perangkat.', style: TextStyle(color: muted, fontSize: 11))]);

  Widget miniStat(String label, String value) => Container(margin: const EdgeInsets.only(bottom: 8), padding: const EdgeInsets.all(13), decoration: box(), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(label, style: const TextStyle(color: muted, fontSize: 10, letterSpacing: 1.1)), const SizedBox(height: 4), Text(value, style: const TextStyle(fontWeight: FontWeight.bold))]));
  Widget section(String s) => Padding(padding: const EdgeInsets.only(bottom: 10), child: Text(s, style: const TextStyle(color: blue, fontWeight: FontWeight.w900, letterSpacing: 1.4)));
  BoxDecoration box() => BoxDecoration(color: panel, borderRadius: BorderRadius.circular(16), border: Border.all(color: Colors.white10));
  Future<void> _confirmReset() async { final yes = await showDialog<bool>(context: context, builder: (c) => AlertDialog(backgroundColor: panel, title: const Text('Reset player?'), content: const Text('Semua profil, EXP, jadwal dan catatan progres lokal akan dihapus.'), actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('BATAL')), FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('RESET'))])); if (yes == true) await widget.onReset(); }
}

String phaseName(int day) => day < 28 ? 'PHASE 01 — ADAPTATION' : day < 56 ? 'PHASE 02 — BUILDING' : 'PHASE 03 — PROGRESSION';
String avatarName(int stage) => ['ROOKIE', 'AWAKENED', 'ASCENDANT'][stage];
String avatarDescription(int stage) => ['Awal perjalanan. Bangun kebiasaan dan catat kondisi tubuh.', 'Konsistensi mulai terbentuk. Terus pantau latihan dan pengukuran.', 'Evolusi hasil konsistensi latihan dan check-in tubuh.'][stage];

class AnimeAvatarPainter extends CustomPainter {
  final int stage;
  AnimeAvatarPainter({required this.stage});
  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2; final scale = size.width / 118;
    final glow = Paint()..color = blue.withOpacity(.12 + stage * .08)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 14);
    canvas.drawCircle(Offset(cx, 54 * scale), 39 * scale, glow);
    final line = Paint()..color = const Color(0xFF9BE3FF)..style = PaintingStyle.stroke..strokeWidth = 1.5 * scale;
    final skin = Paint()..color = const Color(0xFFE7BFA8);
    final hair = Paint()..color = stage == 2 ? const Color(0xFFB8EFFF) : const Color(0xFF17263A);
    final suit = Paint()..color = stage == 0 ? const Color(0xFF24415D) : stage == 1 ? const Color(0xFF17618B) : const Color(0xFF1A8FC2);
    canvas.drawOval(Rect.fromCenter(center: Offset(cx, 124 * scale), width: 63 * scale, height: 54 * scale), suit);
    canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromCenter(center: Offset(cx, 85 * scale), width: 16 * scale, height: 23 * scale), Radius.circular(5 * scale)), skin);
    canvas.drawOval(Rect.fromCenter(center: Offset(cx, 51 * scale), width: 43 * scale, height: 54 * scale), skin);
    final hairPath = Path()..moveTo(cx - 22 * scale, 48 * scale)..quadraticBezierTo(cx - 28 * scale, 15 * scale, cx, 20 * scale)..quadraticBezierTo(cx + 29 * scale, 13 * scale, cx + 23 * scale, 48 * scale)..lineTo(cx + 10 * scale, 39 * scale)..lineTo(cx + 3 * scale, 50 * scale)..lineTo(cx - 4 * scale, 38 * scale)..lineTo(cx - 14 * scale, 51 * scale)..close();
    canvas.drawPath(hairPath, hair);
    final eye = Paint()..color = const Color(0xFF07111E);
    canvas.drawOval(Rect.fromCenter(center: Offset(cx - 9 * scale, 54 * scale), width: 4 * scale, height: 2.5 * scale), eye);
    canvas.drawOval(Rect.fromCenter(center: Offset(cx + 9 * scale, 54 * scale), width: 4 * scale, height: 2.5 * scale), eye);
    canvas.drawLine(Offset(cx - 8 * scale, 65 * scale), Offset(cx + 8 * scale, 65 * scale), line);
    final collar = Paint()..color = blue;
    canvas.drawPath(Path()..moveTo(cx - 12 * scale, 101 * scale)..lineTo(cx, 117 * scale)..lineTo(cx + 12 * scale, 101 * scale)..close(), collar);
    if (stage >= 1) { canvas.drawCircle(Offset(cx - 31 * scale, 57 * scale), 3 * scale, collar); canvas.drawCircle(Offset(cx + 31 * scale, 57 * scale), 3 * scale, collar); }
    if (stage >= 2) { final aura = Paint()..color = blue.withOpacity(.75)..style = PaintingStyle.stroke..strokeWidth = 1.2 * scale; canvas.drawOval(Rect.fromCenter(center: Offset(cx, 70 * scale), width: 103 * scale, height: 132 * scale), aura); }
    canvas.drawLine(Offset(cx - 31 * scale, 139 * scale), Offset(cx + 31 * scale, 139 * scale), line);
  }
  @override
  bool shouldRepaint(covariant AnimeAvatarPainter oldDelegate) => oldDelegate.stage != stage;
}
